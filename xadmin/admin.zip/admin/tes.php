<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <script src="vendor/sweetalert2/dist/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="vendor/sweetalert2/dist/sweetalert2.min.css">
</head>

<body>


  <script src="vendor/sweetalert2/dist/sweetalert2.all.min.js"></script>
  <!-- Optional: include a polyfill for ES6 Promises for IE11 -->
  <script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
  <script>
    swal.fire(
      'Success!',
      'Data Anda Tersimpan!',
      'success'
    );
  </script>
</body>

</html>